#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int mn_rute, mh, jml_penumpang,i,j,totalp, no_pay=0, harga=0, h=0, kls;
char mn_kls, konfirm;

typedef struct{
    char nama[25];
    char asal[25];
    char tujuan[25];
    char rute[20];
    char tanggal[20];
    char berangkat[20];
    char tiba[20];
    int kls_e;
    int kls_b;
    int kls_x;
    int kuota_e;
    int kuota_b;
    int kuota_x;
    int harga;
    int nomor;
}struk;

struk nm_penumpang[20],c;




struk kelas[3]={
    {"Ekonomi<E>"},
    {"Bisnis<B>"},
    {"Eksekutif<X>"},
};

void tiketku(){
    printf("============================================\n");
    printf("                    Tiketku                 \n");
    printf("============================================\n\n");

}
void menuhome(){
    printf(" > Halaman Home                             \n");
    printf("--------------------------------------------\n\n");
    printf("DAFTAR MENU :\n");
    printf("\t[1] Booking Tiket\n");
    printf("\t[2] Biodata Pembuat\n");
    printf("\t[3] Keluar\n");

}
void menudashboard(){
    printf(" > Halaman Menu                             \n");
    printf("--------------------------------------------\n\n");
    printf("\tDaftar Menu :\n");
    printf("\t[1] Tiket Pesawat\n");
    printf("\t[2] Tiket Kereta\n");
    printf("\t[3] Tiket Kapal\n");
    printf("\t[4] Riwayat Transaksi\n");
    printf("\t[5] Akun\n");
    printf("\t[6] Keluar\n");
}
void daftarmenu(){
    printf("\n\tDaftar Menu   : \n");
    printf("\t[1] Filter\n");
    printf("\t[2] Pesan Tiket\n");
    printf("\t[3] Kembali\n\n");
 }
void pesawat(){
    printf("=================================================================\n");
    printf("                         JADWAL PENERBANGAN                      \n");
    printf("=================================================================\n\n");
}

struk pes[15]={
    { "Garuda Indonesia", "Jakarta", "Denpasar", "CGK-DPS", "12-01-2019", "18.30", "20.00",  829000, 2048000, 10000000, 350, 18, 8 },
    { "Citilink", "Yogyakarta", "Jakarta", "JOG-CGK", "16-01-2019", "15.10", "16.15", 484000, 1243000, 80000000, 350, 18, 8 },
    { "Lion Air", "Surabaya", "Yogyakarta", "SUB-JOG", "12-01-2019", "21.00", "22.45", 737000, 4020000, 95000000, 350, 18, 8 },
    { "Garuda Indonesia", "Denpasar", "Surabaya", "DPS-SUB", "21-01-2018", "10.30", "11.15", 950000, 3610000, 15000000, 350, 18, 8 },
    { "Lion Air", "Makassar", "Yogyakarta", "UPG-JOG", "20-01-2019", "20.00", "21.00", 1200000, 4100000, 20000000, 350, 18, 8 },
    { "Argo Lawu", "Jakarta", "Solo", "GMR-SLO", "22-01-2019", "06.30", "14.30", 2600000, 370000, 440000, 400, 250, 150 },
    { "Argo Wilis", "Bandung", "Surabaya", "BDG-SBY", "20-01-2019", "15.30", "22.30", 200000, 285000, 360000, 400, 250, 150 },
    { "Bima", "Jakarta", "Malang", "PSE-MLG", "05-02-2019", "14.00", "23.00", 225000, 300000, 380000, 450, 250, 100 },
    { "Purwojaya", "Jakarta", "Purwokerto", "PSE-PWT", "10-02-2019", "09.00", "13.30", 170000, 220000, 3250000, 300, 250, 250 },
    { "Taksaka", "Jakarta", "Yogyakarta", "PSE-JOG", "29-01-2019", "13.00", "20.00", 190000, 300000, 410000, 250, 300, 250 },
    {"KM Wilis","Surabaya","Jakarta","SBY-JKT","12-12-2019","18.30","21.00",484000, 1243000, 80000000, 350, 18, 8},
    {"KM Awu","Surabaya","Medan","SBY-MDN","12-12-2019","13.00","17.00",1200000, 4100000, 20000000, 350, 18, 8 },
    {"KM Binaia","Surabaya","Papua","SBY-PAP","12-12-2019","16.30","05.20",737000, 4020000, 95000000, 350, 18, 8},
    {"KM Bukit Raya","Surabaya","Lampung","SBY-LPN","12-12-2019","11.30","16.47",650000, 1610000, 9000000, 350, 18, 8},
    {"KM Leuser","Surabaya","Aceh", "SBY-ACH","12-12-2019","11.30","20.02",1000000, 1510000, 8700000, 350, 18, 8},
    };

int caripesawat(int tgl){
    int i, ret;
    system("cls");
    for(i=0;i<5;i++){
            ret = strcmp(tgl, pes[i].tanggal);
                if(ret==0){
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\tJadwal Ke %i\t\t\t\n", i+1);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\t\t\t\t%s\t\t\t\n", pes[i].nama);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\t|\tRute\t\t|\t%s\n",pes[i].rute);
                    printf("\t\t\t|\tTanggal\t\t|\t%s\n",pes[i].tanggal);
                    printf("\t\t\t|\tBerangkat\t|\t%s\n",pes[i].berangkat);
                    printf("\t\t\t|\tTiba\t\t|\tJam %i\n",pes[i].tiba);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                }
        }
}

void kelaspesawat(){
    printf("Pilih Kelas <E>/<B>/<X> : ");
    scanf("%s", &mn_kls);
    switch (toupper(mn_kls)){
        case 'E':
            printf("Input Jumlah Penumpang : ");
            scanf("%i", &jml_penumpang);
            pes[mh].kuota_e=pes[mh].kuota_e-jml_penumpang;
            for(i=0; i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_e;
                harga = pes[mh].kls_e;
                kls = 0;
            }
            h=h+1;
            pes[h].harga=totalp;
            break;
        case 'B':
            printf("Input Jumlah Penumpang : ");
            scanf("%i", &jml_penumpang);
            pes[mh].kuota_b=pes[mh].kuota_b-jml_penumpang;
            for(i=0; i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_b;
                harga = pes[mh].kls_b;
                kls=1;
            }
            h=h+1;
            pes[h].harga=totalp;
            break;
        case 'X':
        printf("Input Jumlah Penumpang : ");
        scanf("%i", &jml_penumpang);
        pes[mh].kuota_x=pes[mh].kuota_x-jml_penumpang;
        for(i=0; i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_x;
                harga = pes[mh].kls_x;
                kls=2;
        }
            h=h+1;
            pes[h].harga=totalp;
            break;
    }
}

void totalpembayaranpesawat(){
system("cls");
        tiketku();
        printf("> Halaman Pembayaran Tiket\n");
        printf("--------------------------------------------\n\n");
        printf("Total Pembayaran : Rp. %i\n\n",totalp);
        printf("Silahkan Transfer Pada Virtual Account di bawah ini :\n");
        printf("*>Verifikasi Otomatis Dilakukan Setelah Pembayaran Selesai\n\n");
        printf("\t>Bank BCA : 1201389813\n");
        printf("\t>Bank BRI : 9309109131\n\n");
    printf("Lanjutkan Pembayaran Tekan <Y>: ");
    scanf("%s", &konfirm);
    if((konfirm=='Y')||(konfirm=='y')){
            no_pay=no_pay+1;
            pes[no_pay].nomor=no_pay;
            printf("=================================================================\n");
            printf("\t\t\tTiket Penerbangan\t\t\t\n");
            printf("=================================================================\n");
            printf("No. Transaksi\t\t\t: PAY-%i\n", pes[no_pay].nomor);
            printf("-----------------------------------------------------------------\n");
            printf("\tRute\t\t\t:\t%s\n",pes[mh].rute);
            printf("\tPenerbangan\t\t:\t%s-%s\n",pes[mh].asal,pes[mh].tujuan);
            printf("\tMaskapai\t\t:\t%s\n",pes[mh].nama);
            printf("\tKelas\t\t\t:\t%s\n", kelas[kls].nama);
            printf("\tGerbang\t\t\t:\tA7\n");
            printf("\tTanggal\t\t\t:\t%s\n",pes[mh].tanggal);
            printf("\tJam Berangkat\t\t:\tJam %s\n",pes[mh].berangkat);
            printf("\tJam Tiba\t\t:\tJam %s\n",pes[mh].tiba);
            printf("-----------------------------------------------------------------\n");
            printf("Nama Penumpang : \n");
            for(i=0; i<jml_penumpang; i++){
                printf("%i. %s \n", i+1, nm_penumpang[i].nama);
            }
            printf("-----------------------------------------------------------------\n");
            printf("\tHarga Tiket\t\t:\t%i\n",harga);
            printf("\tJumlah Tiket\t\t:\t%i\n",jml_penumpang);
            printf("\tTotal Pembayaran\t:\t%i\n", totalp);
            printf("-----------------------------------------------------------------\n");
    }
}

void pesantiketpesawat(){
        printf("Pilih Jadwal <1>/<2>/<3>/<4>/<5> : ");
        scanf("%i", &mn_rute);
        if(mn_rute==1){
            mh=0;
        }else if(mn_rute==2){
            mh=1;
        }else if(mn_rute==3){
            mh=2;
        }else if(mn_rute==4){
            mh=3;
        }else if(mn_rute==5){
            mh=4;
        }
            system("cls");
            pesawat();
            printf("=================================================================\n");
            printf("|\tMaskapai\t|\t%s\n",pes[mh].nama);
            printf("|\tRute\t\t|\t%s\n",pes[mh].rute);
            printf("|\tAsal\t\t|\t%s\n",pes[mh].asal);
            printf("|\tTujuan\t\t|\t%s\n",pes[mh].tujuan);
            printf("=================================================================\n");
            printf("\t\t\tHarga Tiket\n");
            printf("-----------------------------------------------------------------\n");
            printf("Ekonomi<E>\tBisnis<B>\tEksekutif<X>\n");
            printf("-----------------------------------------------------------------\n");
            printf("Rp. %i\tRp. %i\tRp. %i\n", pes[mh].kls_e,pes[mh].kls_b, pes[mh].kls_x);
            printf("=================================================================\n");
            printf("\t\t\tKuota Tiket\n");
            printf("-----------------------------------------------------------------\n");
            printf("Ekonomi<E>\tBisnis<B>\tEksekutif<X>\n");
            printf("-----------------------------------------------------------------\n");
            printf("%i\t\t%i\t\t%i\n", pes[mh].kuota_e,pes[mh].kuota_b, pes[mh].kuota_x);
            printf("=================================================================\n");
            kelaspesawat();
            totalpembayaranpesawat();
                }

void kereta(){
    printf("=================================================================\n");
    printf("                         JADWAL KERETA                      \n");
    printf("=================================================================\n\n");
}

int carikereta(int tgl){
    int i, ret;
    system("cls");
    for(i=5;i<10;i++){
            ret = strcmp(tgl, pes[i].tanggal);
                if(ret==0){
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\tJadwal Ke %i\t\t\t\n", i-4);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\t\t\t\t%s\t\t\t\n", pes[i].nama);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\t|\tRute\t\t|\t%s\n",pes[i].rute);
                    printf("\t\t\t|\tTanggal\t\t|\t%s\n",pes[i].tanggal);
                    printf("\t\t\t|\tBerangkat\t|\t%s\n",pes[i].berangkat);
                    printf("\t\t\t|\tTiba\t\t|\tJam %i\n",pes[i].tiba);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                }
        }
}

void kelaskereta(){
    printf("Pilih Kelas <E>/<B>/<X> : ");
    scanf("%s", &mn_kls);
    switch (toupper(mn_kls)){
        case 'E':
            printf("Input Jumlah Penumpang : ");
            scanf("%i", &jml_penumpang);
            pes[mh].kuota_e=pes[mh].kuota_e-jml_penumpang;
            for(i=0 ;i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_e;
                harga = pes[mh].kls_e;
                kls = 0;
                j++;
            }
            h=h+1;
            pes[h].harga=totalp;
            break;
        case 'B':
            printf("Input Jumlah Penumpang : ");
            scanf("%i", &jml_penumpang);
            pes[mh].kuota_b=pes[mh].kuota_b-jml_penumpang;
            for(i=0; i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_b;
                harga = pes[mh].kls_b;
                kls=1;
            }
            h=h+1;
            pes[h].harga=totalp;
            break;
        case 'X':
        printf("Input Jumlah Penumpang : ");
        scanf("%i", &jml_penumpang);
        pes[mh].kuota_x=pes[mh].kuota_x-jml_penumpang;
        for(i=0; i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_x;
                harga = pes[mh].kls_x;
                kls=2;
        }
            h=h+1;
            pes[h].harga=totalp;
            break;
        default:
            printf("Kelas Tidak Ada!\n");
    }
}

void totalpembayarankereta(){
system("cls");
        tiketku();
        printf("> Halaman Pembayaran Tiket\n");
        printf("--------------------------------------------\n\n");
        printf("Total Pembayaran : Rp. %i\n\n",totalp);
        printf("Silahkan Transfer Pada Virtual Account di bawah ini :\n");
        printf("*>Verifikasi Otomatis Dilakukan Setelah Pembayaran Selesai\n\n");
        printf("\t>Bank BCA : 1201389813\n");
        printf("\t>Bank BRI : 9309109131\n\n");
    printf("Lanjutkan Pembayaran Tekan <Y>: ");
    scanf("%s", &konfirm);
    if((konfirm=='Y')||(konfirm=='y')){
            no_pay=no_pay+1;
            pes[no_pay].nomor=no_pay;
            printf("=================================================================\n");
            printf("\t\t\tTiket Kereta\t\t\t\n");
            printf("=================================================================\n");
            printf("No. Transaksi\t\t\t: PAY-%i\n", pes[no_pay].nomor);
            printf("-----------------------------------------------------------------\n");
            printf("\tRute\t\t\t:\t%s\n",pes[mh].rute);
            printf("\tTujuan\t\t\t:\t%s-%s\n",pes[mh].asal,pes[mh].tujuan);
            printf("\tNama\t\t\t:\t%s\n",pes[mh].nama);
            printf("\tKelas\t\t\t:\t%s\n", kelas[kls].nama);
            printf("\tTanggal\t\t\t:\t%s\n",pes[mh].tanggal);
            printf("\tJam Berangkat\t\t:\tJam %s\n",pes[mh].berangkat);
            printf("\tJam Tiba\t\t:\tJam %s\n",pes[mh].tiba);
            printf("-----------------------------------------------------------------\n");
            printf("Nama Penumpang : \n");
            for(i=0; i<jml_penumpang; i++){
                printf("%i. %s \n", i+1, nm_penumpang[i].nama);
            }
            printf("-----------------------------------------------------------------\n");
            printf("\tHarga Tiket\t\t:\t%i\n",harga);
            printf("\tJumlah Tiket\t\t:\t%i\n",jml_penumpang);
            printf("\tTotal Pembayaran\t:\t%i\n", totalp);
            printf("-----------------------------------------------------------------\n");
    }
}

void pesantiketkereta(){
        printf("Pilih Jadwal <1>/<2>/<3>/<4>/<5> : ");
        scanf("%i", &mn_rute);
        if(mn_rute==1){
            mh=5;
        }else if(mn_rute==2){
            mh=6;
        }else if(mn_rute==3){
            mh=7;
        }else if(mn_rute==4){
            mh=8;
        }else if(mn_rute==5){
            mh=9;
        }
            system("cls");
            pesawat();
            printf("=================================================================\n");
            printf("|\tMaskapai\t|\t%s\n",pes[mh].nama);
            printf("|\tRute\t\t|\t%s\n",pes[mh].rute);
            printf("|\tAsal\t\t|\t%s\n",pes[mh].asal);
            printf("|\tTujuan\t\t|\t%s\n",pes[mh].tujuan);
            printf("=================================================================\n");
            printf("\t\t\tHarga Tiket\n");
            printf("-----------------------------------------------------------------\n");
            printf("Ekonomi<E>\tBisnis<B>\tEksekutif<X>\n");
            printf("-----------------------------------------------------------------\n");
            printf("Rp. %i\tRp. %i\tRp. %i\n", pes[mh].kls_e,pes[mh].kls_b, pes[mh].kls_x);
            printf("=================================================================\n");
            printf("\t\t\tKuota Tiket\n");
            printf("-----------------------------------------------------------------\n");
            printf("Ekonomi<E>\tBisnis<B>\tEksekutif<X>\n");
            printf("-----------------------------------------------------------------\n");
            printf("%i\t\t%i\t\t%i\n", pes[mh].kuota_e,pes[mh].kuota_b, pes[mh].kuota_x);
            printf("=================================================================\n");
            kelaskereta();
            totalpembayarankereta();
                }

void kapal(){
    printf("=================================================================\n");
    printf("                         JADWAL KAPAL                      \n");
    printf("=================================================================\n\n");
}

int carikapal(int tgl){
    int i, ret;
    system("cls");
    for(i=10;i<15;i++){
            ret = strcmp(tgl, pes[i].tanggal);
                if(ret==0){
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\tJadwal Ke %i\t\t\t\n", i-9);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\t\t\t\t%s\t\t\t\n", pes[i].nama);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                    printf("\t\t\t|\tRute\t\t|\t%s\n",pes[i].rute);
                    printf("\t\t\t|\tTanggal\t\t|\t%s\n",pes[i].tanggal);
                    printf("\t\t\t|\tBerangkat\t|\t%s\n",pes[i].berangkat);
                    printf("\t\t\t|\tTiba\t\t|\tJam %i\n",pes[i].tiba);
                    printf("\t\t\t-----------------------------------------------------------------\n");
                }
        }
}

void kelaskapal(){
    printf("Pilih Kelas <E>/<B>/<X> : ");
    scanf("%s", &mn_kls);
    switch (toupper(mn_kls)){
        case 'E':
            printf("Input Jumlah Penumpang : ");
            scanf("%i", &jml_penumpang);
            pes[mh].kuota_e=pes[mh].kuota_e-jml_penumpang;
            for(i=0 ;i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_e;
                harga = pes[mh].kls_e;
                kls = 0;
                j++;
            }
            h=h+1;
            pes[h].harga=totalp;
            break;
        case 'B':
            printf("Input Jumlah Penumpang : ");
            scanf("%i", &jml_penumpang);
            pes[mh].kuota_b=pes[mh].kuota_b-jml_penumpang;
            for(i=0; i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_b;
                harga = pes[mh].kls_b;
                kls=1;
            }
            h=h+1;
            pes[h].harga=totalp;
            break;
        case 'X':
        printf("Input Jumlah Penumpang : ");
        scanf("%i", &jml_penumpang);
        pes[mh].kuota_x=pes[mh].kuota_x-jml_penumpang;
        for(i=0; i<jml_penumpang; i++){
                printf("%i. Masukan Nama : ", i+1);
                scanf("%s", &nm_penumpang[i].nama);
                totalp = jml_penumpang*pes[mh].kls_x;
                harga = pes[mh].kls_x;
                kls=2;
        }
            h=h+1;
            pes[h].harga=totalp;
            break;
    }
}

void totalpembayarankapal(){
system("cls");
        tiketku();
        printf("> Halaman Pembayaran Tiket\n");
        printf("--------------------------------------------\n\n");
        printf("Total Pembayaran : Rp. %i\n\n",totalp);
        printf("Silahkan Transfer Pada Virtual Account di bawah ini :\n");
        printf("*>Verifikasi Otomatis Dilakukan Setelah Pembayaran Selesai\n\n");
        printf("\t>Bank BCA : 1201389813\n");
        printf("\t>Bank BRI : 9309109131\n\n");
    printf("Lanjutkan Pembayaran Tekan <Y>: ");
    scanf("%s", &konfirm);
    if((konfirm=='Y')||(konfirm=='y')){
            no_pay=no_pay+1;
            pes[no_pay].nomor=no_pay;
            printf("=================================================================\n");
            printf("\t\t\tTiket Kapal\t\t\t\n");
            printf("=================================================================\n");
            printf("No. Transaksi\t\t\t: PAY-%i\n", pes[no_pay].nomor);
            printf("-----------------------------------------------------------------\n");
            printf("\tRute\t\t\t:\t%s\n",pes[mh].rute);
            printf("\tTujuan\t\t\t:\t%s-%s\n",pes[mh].asal,pes[mh].tujuan);
            printf("\tNama\t\t\t:\t%s\n",pes[mh].nama);
            printf("\tKelas\t\t\t:\t%s\n", kelas[kls].nama);
            printf("\tTanggal\t\t\t:\t%s\n",pes[mh].tanggal);
            printf("\tJam Berangkat\t\t:\tJam %s\n",pes[mh].berangkat);
            printf("\tJam Tiba\t\t:\tJam %s\n",pes[mh].tiba);
            printf("-----------------------------------------------------------------\n");
            printf("Nama Penumpang : \n");
            for(i=0; i<jml_penumpang; i++){
                printf("%i. %s \n", i+1, nm_penumpang[i].nama);
            }
            printf("-----------------------------------------------------------------\n");
            printf("\tHarga Tiket\t\t:\t%i\n",harga);
            printf("\tJumlah Tiket\t\t:\t%i\n",jml_penumpang);
            printf("\tTotal Pembayaran\t:\t%i\n", totalp);
            printf("-----------------------------------------------------------------\n");
    }
}

void pesantiketkapal(){
        printf("Pilih Jadwal <1>/<2>/<3>/<4>/<5> : ");
        scanf("%i", &mn_rute);
        if(mn_rute==1){
            mh=10;
        }else if(mn_rute==2){
            mh=11;
        }else if(mn_rute==3){
            mh=12;
        }else if(mn_rute==4){
            mh=13;
        }else if(mn_rute==5){
            mh=14;
        }
            system("cls");
            kapal();
            printf("=================================================================\n");
            printf("|\tNama\t\t|\t%s\n",pes[mh].nama);
            printf("|\tRute\t\t|\t%s\n",pes[mh].rute);
            printf("|\tAsal\t\t|\t%s\n",pes[mh].asal);
            printf("|\tTujuan\t\t|\t%s\n",pes[mh].tujuan);
            printf("=================================================================\n");
            printf("\t\t\tHarga Tiket\n");
            printf("-----------------------------------------------------------------\n");
            printf("Ekonomi<E>\tBisnis<B>\tEksekutif<X>\n");
            printf("-----------------------------------------------------------------\n");
            printf("Rp. %i\tRp. %i\tRp. %i\n", pes[mh].kls_e,pes[mh].kls_b, pes[mh].kls_x);
            printf("=================================================================\n");
            printf("\t\t\tKuota Tiket\n");
            printf("-----------------------------------------------------------------\n");
            printf("Ekonomi<E>\tBisnis<B>\tEksekutif<X>\n");
            printf("-----------------------------------------------------------------\n");
            printf("%i\t\t%i\t\t%i\n", pes[mh].kuota_e,pes[mh].kuota_b, pes[mh].kuota_x);
            printf("=================================================================\n");
            kelaskapal();
            totalpembayarankapal();
                }

int main(){
    char username[20], pwd[20], re_pwd[20],pwd_new[20],re_pwd_new[20], tgl[20], username_new[20];
    int pilihmenu, ret, jmltiket=1;

do{
    system("cls");
    utama:
    system("cls");
    tiketku();
    menuhome();
    printf("Pilih Menu<1>/<2>/<3> : ");
    scanf("%i", &pilihmenu);
    if(pilihmenu==1){
        goto daftar;
    }else if(pilihmenu==2){
        goto biodata;
    }else if(pilihmenu==3){
        return EXIT_SUCCESS;
    }
    }while(pilihmenu!=3);

//Menu Booking Tiket

daftar:
    system("cls");
    tiketku();
    printf("> Halaman Daftar\n");
    printf("--------------------------------------------\n\n");
    printf("\tAYO DAFTARKAN DULU AKUN ANDA . .\n");
    printf("\t--------------------------------------------\n\n");
    printf("Masukan Nama Anda : ");
    scanf("%s", &username);
    printf("Masukan Password : ");
    scanf("%s", &pwd);
    printf("Konfirmasi Password : ");
    scanf("%s", &re_pwd);
    ret=strcmp(pwd,re_pwd);
    if(ret==0){
        system("cls");
        goto dashboard;
    }else{
        system("cls");
        printf("Uppss, password tidak valid!\n");
        goto daftar;
    }

//Menu Dashboard

dashboard:
do{
    system("cls");
    tiketku();
    menudashboard();
    printf("Pilih Menu <1>/<2>/<3>/<4>/<5>/<6>/<7> : ");
    scanf("%i", &pilihmenu);
    if(pilihmenu==1){
        system("cls");
        goto pesawat;
    }else if(pilihmenu==2){
        system("cls");
        goto kereta;
    }else if(pilihmenu==3){
        system("cls");
        goto kapal;
    }else if(pilihmenu==4){
        system("cls");
        goto riwayat;
    }else if(pilihmenu==5){
        goto akun;
    }else if(pilihmenu==6){
        return EXIT_SUCCESS;
    }
    }while(pilihmenu!=6);

//Menu Pesan Tiket Pesawat

pesawat:
    system("cls");
    pesawat();
    for(int i=0; i<5;i++){
            printf("-----------------------------------------------------------------\n");
            printf("\t\t\tJadwal Ke %i\t\t\t\n", i+1);
            printf("-----------------------------------------------------------------\n");
            printf("|\tMaskapai\t|\t%s\n",pes[i].nama);
            printf("|\tRute\t\t|\t%s\n",pes[i].rute);
            printf("|\tTanggal\t\t|\t%s\n",pes[i].tanggal);
            printf("|\tBerangkat\t|\t%s\n",pes[i].berangkat);
            printf("|\tTiba\t\t|\t%s\n",pes[i].tiba);
            printf("-----------------------------------------------------------------\n");
    }
    do{
    daftarmenu();
    printf("Pilih Menu <1>/<2>/<3> : ");
    scanf("%i", &pilihmenu);
    if(pilihmenu==1){
        printf("Masukan Tanggal : ");
        scanf("%s", &tgl);
        caripesawat(tgl);
    }else if(pilihmenu==2){
        pesantiketpesawat();
        jmltiket=jmltiket+1;
        printf("Pesan Tiket Lagi <Y>/<N> : ");
        scanf("%s", &konfirm);
        if((konfirm=='Y')||(konfirm=='y')){
            goto pesawat;
        }else if((konfirm=='N')||(konfirm=='n')){
            goto dashboard;
        }
    }else if(pilihmenu==3){
        goto dashboard;
    }
    }while(pilihmenu!=3);

//Menu Pesan Tiket Kereta

kereta:
    system("cls");
    kereta();
    for(int i=5; i<10;i++){
            printf("-----------------------------------------------------------------\n");
            printf("\t\t\tJadwal Ke %i\t\t\t\n", i-4);
            printf("-----------------------------------------------------------------\n");
            printf("|\tNama\t\t|\t%s\n",pes[i].nama);
            printf("|\tRute\t\t|\t%s\n",pes[i].rute);
            printf("|\tTanggal\t\t|\t%s\n",pes[i].tanggal);
            printf("|\tBerangkat\t|\t%s\n",pes[i].berangkat);
            printf("|\tTiba\t\t|\t%s\n",pes[i].tiba);
            printf("-----------------------------------------------------------------\n");
    }
    do{
    daftarmenu();
    printf("Pilih Menu <1>/<2>/<3> : ");
    scanf("%i", &pilihmenu);
    if(pilihmenu==1){
        printf("Masukan Tanggal : ");
        scanf("%s", &tgl);
        carikereta(tgl);
    }else if(pilihmenu==2){
        pesantiketkereta();
        jmltiket=jmltiket+1;
        printf("Pesan Tiket Lagi <Y>/<N> : ");
        scanf("%s", &konfirm);
        if((konfirm=='Y')||(konfirm=='y')){
            goto kereta;
        }else if((konfirm=='N')||(konfirm=='n')){
            goto dashboard;
        }
    }else if(pilihmenu==3){
        goto dashboard;
    }
    }while(pilihmenu!=3);

//Menu Pesan Tiket Kapal

kapal:
    system("cls");
    kapal();
    for(int i=10; i<15;i++){
            printf("-----------------------------------------------------------------\n");
            printf("\t\t\tJadwal Ke %i\t\t\t\n", i-9);
            printf("-----------------------------------------------------------------\n");
            printf("|\tNama\t\t|\t%s\n",pes[i].nama);
            printf("|\tRute\t\t|\t%s\n",pes[i].rute);
            printf("|\tTanggal\t\t|\t%s\n",pes[i].tanggal);
            printf("|\tBerangkat\t|\t%s\n",pes[i].berangkat);
            printf("|\tTiba\t\t|\t%s\n",pes[i].tiba);
            printf("-----------------------------------------------------------------\n");
    }
    do{
    daftarmenu();
    printf("Pilih Menu <1>/<2>/<3> : ");
    scanf("%i", &pilihmenu);
    if(pilihmenu==1){
        printf("Masukan Tanggal : ");
        scanf("%s", &tgl);
        carikapal(tgl);
    }else if(pilihmenu==2){
        pesantiketkapal();
        jmltiket=jmltiket+1;
        printf("Pesan Tiket Lagi <Y>/<N> : ");
        scanf("%s", &konfirm);
        if((konfirm=='Y')||(konfirm=='y')){
            goto kapal;
        }else if((konfirm=='N')||(konfirm=='n')){
            goto dashboard;
        }
    }else if(pilihmenu==3){
        goto dashboard;
    }
    }while(pilihmenu!=3);



//Riwayar Transaksi

riwayat:
    tiketku();
    printf(" > Halaman Riwayat Transaksi                \n");
    printf("--------------------------------------------\n\n");
    for(i=1; i<jmltiket;i++){
        printf("Kode Transaksi\t\t: PAY-%i\n",pes[i].nomor);
        printf("Total Transaksi\t\t: %i\n", pes[i].harga);
        printf("--------------------------------------------\n");
    }
    printf("Daftar Menu : \n");
    printf("1. Urutkan Berdasarkan Pembayaran Termahal\n");
    printf("2. Urutkan Berdasarkan Pembayaran Termurah\n");
    printf("3. Kembali \n");
    printf("Pilih Menu <1>/<2>/<3> : ");
    scanf("%i", &pilihmenu);
    if(pilihmenu==1){
        for(i=1;i<jmltiket;i++){
            for(j=1;j<jmltiket-1;j++){
                if(pes[j].harga<pes[j+1].harga){
                    c=pes[j];
                    pes[j]=pes[j+1];
                    pes[j+1]=c;
                }
            }
        }
        system("cls");
        for(i=1; i<jmltiket;i++){
        printf("Kode Transaksi\t\t: PAY-%i\n",pes[i].nomor);
        printf("Total Transaksi\t\t: %i\n", pes[i].harga);
        printf("--------------------------------------------\n");

        goto riwayat;
    }
    }else if(pilihmenu==2){
        for(i=1;i<jmltiket;i++){
            for(j=1;j<jmltiket-1;j++){
                if(pes[j].harga>pes[j+1].harga){
                    c=pes[j];
                    pes[j]=pes[j+1];
                    pes[j+1]=c;
                }
            }
        }
        system("cls");
        for(i=1; i<jmltiket;i++){
        printf("Kode Transaksi\t\t: PAY-%i\n",pes[i].nomor);
        printf("Total Transaksi\t\t: %i\n", pes[i].harga);
        printf("--------------------------------------------\n");
        goto riwayat;
        }
    }else if(pilihmenu==3){
        goto dashboard;
    }

 //Menu Akun

akun:
    system("cls");
    tiketku();
    printf(" > Halaman Akun                             \n");
    printf("--------------------------------------------\n\n");
    printf("Username : %s", username);
    printf("\nPassword : %s", pwd);
    printf("\n\n daftar menu : ");
    printf("\n[1] Ganti username");
    printf("\n[2] Ganti password");
    printf("\n[3] Kembali");
    printf("\n\nPilih menu : ");
    scanf("%i",&pilihmenu);
    if(pilihmenu==1){
        printf("Masukkan username baru : ");
        scanf("%s",&username_new);
        printf("Masukkan password : ");
        scanf("%s",&pwd);
        ret = strcmp(pwd, re_pwd);
        if(ret==0){
            strcpy(username,username_new);
        }
    }else if(pilihmenu==2){
        do{
        printf("Masukkan password lama: ");
        scanf("%s",&pwd);
        ret = strcmp(pwd,re_pwd);
        if(ret==0){
           printf("Masukkan password baru : ");
            scanf("%s",&pwd_new);
            printf("Masukan Lagi : ");
            scanf("%s",&re_pwd_new);
            ret = strcmp(re_pwd_new,pwd_new);
            if(ret==0){
            strcpy(re_pwd,re_pwd_new);
             strcpy(pwd,pwd_new);
            }
        }
    }while(ret!=0);
    }else if(pilihmenu==3){
        system("cls");
        goto dashboard;
    }
    system("cls");
    goto akun;

//Menu Biodata Pembuat
biodata:
    system("cls");
    tiketku();
    printf(" > Halaman Biodata Pembuat                             \n");
    printf("--------------------------------------------\n\n");
    printf("Pertama\n");
    printf("--------------------------------------------\n\n");
    printf("Nama\t:\tM. Rafi Adityawarman\n");
    printf("Nim\t:\t1202190040\n");
    printf("--------------------------------------------\n\n");
    printf("Kedua\n");
    printf("--------------------------------------------\n\n");
    printf("Nama\t:\tGrahito Ardani B\n");
    printf("Nim\t:\t1202199006\n");
    printf("--------------------------------------------\n\n");
    printf("Kembali Tekan Enter ");
    system("pause");
    goto utama;
}
